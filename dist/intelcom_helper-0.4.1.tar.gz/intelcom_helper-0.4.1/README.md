Code used frequently at Intelcom by Data Science Team

To build the package, run:
> python setup.py sdist bdist_wheel
> 
> twine upload dist/*  